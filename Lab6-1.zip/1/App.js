
import React from "react";


function App() {

  const currentYear = new Date().getFullYear();
  const isLoggedIn = true;

  return (
    <div className="App" style={{textAlign: "center"}}>
      <h1>ENSF-381: Full Stack</h1>
      <p>Reach Components</p>
      <p>Current Year: {currentYear}</p>
      <p>{isLoggedIn ? "Welcome Back!" : "Please log in."}</p>

    </div>
  );
}

export default App;
